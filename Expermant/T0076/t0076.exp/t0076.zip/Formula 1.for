<?xml version="1.0" encoding="utf-8"?>
<FormulaAttachement xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Version>1.0.0.2</Version>
  <Comment>This file contains a formula.</Comment>
  <Author>Elsys AG</Author>
  <Formula />
  <Foldings />
  <FontSize>14</FontSize>
  <AttachedDataInfos />
  <AttachedFileData />
  <Breakpoints />
  <CustomDescriptions />
  <RuntimeVersion>2.0</RuntimeVersion>
</FormulaAttachement>